# Enrich and Validate API and App Documentation

## Overview
Enrich-App is a web application designed to perform contact enrichment and validation using an API service.
Users can purchase search credits, use these credits to perform searches, and view their search history.

## Tech Stack
- **Backend**: Node.js, Express.js, AWS SDK v3
- **Frontend**: React, Stripe (Payments Integration)
- **Database**: AWS DynamoDB

## Features
1. User Authentication: Managed using AWS Amplify.
2. Search Credits Management: Credits can be purchased and are deducted when searches are performed.
3. Search History Logging: Logs each search query and API response.
4. Stripe Integration: Handles payments for credit purchases.

## Key API Endpoints
1. `/purchase-pack`
2. `/check-credits`
3. `/use-search`
4. `/get-search-history`

## Next Steps
- Ensure DynamoDB stores user credits and search history persistently.
- Test and refine all endpoints.
